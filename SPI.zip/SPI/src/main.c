/**
 * main.c
 *
 *  Created on: Fri May 17 2024
 *  Author    : Abdallah Darwish
 */
#include "Bit_Operations.h"
#include "Gpio.h"
#include "Rcc.h"
#include "Std_Types.h"
#include "Usart.h"
#include "Utils.h"
#include "Spi.h"
#include "TC72.h"

#define TC72_SELECT() (Gpio_WritePin(GPIO_B, 0, 1)) //select slave "pin number that the device "slave" on it
#define TC72_UNSELECT() (Gpio_WritePin(GPIO_B, 0, 0))
void floatToStr(float val, char data[]);

int main() {
	Rcc_Init();
	Rcc_Enable(RCC_GPIOA);
	Rcc_Enable(RCC_USART2);
	Usart2_Init();

	char usart2Data[] = { '-', ' ', ' ', '.', ' ', ' ', '\r', '\n', '\0' };
	uint8 spiData = 0;
	float32 temperature = 0;

	Rcc_Init();
	Rcc_Enable(RCC_GPIOA);
	Rcc_Enable(RCC_GPIOB);
	Rcc_Enable(RCC_SPI1);
	Rcc_Enable(RCC_USART2);

	/* Slave Select */
	Gpio_ConfigPin(GPIO_B, 0, GPIO_OUTPUT, GPIO_PUSH_PULL);
	Gpio_WritePin(GPIO_B, 0, 0);

	Usart2_Init();
	Spi1_Init(SPI_MASTER, SPI_IDLE_LOW, SPI_SAMPLE_SOCAND_TRANSITION);

	TC72_SELECT();
	Tc72_Init(0x00);
	TC72_UNSELECT();

	while (1) {
		temperature = 0.0f;
		TC72_SELECT();
		Tc72_RegisterRead(0x01, &spiData); // read LSB register that contain fraction part of temprature
		TC72_UNSELECT();

		if (spiData & (1 << 7)) {
			temperature += 0.5f;     // we map from uin8 to float
		}
		if (spiData & (1 << 6)) {
			temperature += 0.25f;
		}

		TC72_SELECT();
		Tc72_RegisterRead(0x02, &spiData); // read MSB register that contain integer part of temprature
		TC72_UNSELECT();

		temperature += (signed char) spiData; //make data signed because temp may be negative

		floatToStr(temperature, usart2Data);   // we want to printf "13.5" how??

		Usart2_TransmitString(usart2Data);  //we want to show data on USART device

		for (int i = 0; i < 100000; i++)
			;

	}
}

void floatToStr(float val, char data[]) {
	if (val < 0) {
		*data = '-';
		data++;
		val *= -1;
	}
	int intVal = val * 100; //if it 28.75 we make it 2875 to deal with it
	data[4] = (intVal % 10) + '0';  //to get the first bit from right "LSB" + '0' to make it character not int
	intVal /= 10; // delete the LSB number
	data[3] = (intVal % 10) + '0';
	data[2] = '.';
	intVal /= 10;
	data[1] = (intVal % 10) + '0';
	intVal /= 10;
	data[0] = (intVal % 10) + '0';

	data[5] = '\r';
	data[6] = '\n';
	data[7] = '\0';
}
