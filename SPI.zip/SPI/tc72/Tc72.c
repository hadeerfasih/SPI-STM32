/**
 * tc72.c
 *
 *  Created on: Wed May 24 2023
 *  Author    : Abdullah Darwish
 */
#include "Spi.h"
#include "tc72.h"

void Tc72_Init(unsigned char Mode) {
    Tc72_RegisterWrite(0x80, Mode);
}

void Tc72_RegisterWrite(unsigned char RegAdd, unsigned char Data) {
	                       // send address to SPI
  Spi1_TransmitRecieveByte(RegAdd | (1 << 7)); //set bit 7 to 1 if it is not to tell the spi that he will write
  Spi1_TransmitRecieveByte(Data); // we sent data to SPI
}

void Tc72_RegisterRead(unsigned char RegAdd, unsigned char* DataPtr) {
    Spi1_TransmitRecieveByte(RegAdd & (~(1 << 7))); //set bit 7 to zero to tell SPI that it will read
    *DataPtr = Spi1_TransmitRecieveByte(0); // send any dummy data to receive
}
