/**
 * Spi.c
 *
 *  Created on: Wed May 24 2023
 *  Author    : Abdullah Darwish
 */
#include "stm32f401xe.h"
#include "Gpio.h"
#include "Gpio_Private.h"
#include "Spi.h"

                  //write 5 in 3 pins so 555     from pin 5 and the register size is 4 bits
#define SPI1_AF_EN() (GPIOA->AFR[0] |= 0x555 << (5 * 4)) //the spi alternate func is 5 to select it write 5




void Spi1_Init(uint8 MasterSlave, uint8 ClkPol, uint8 ClkPhase) {

  Gpio_ConfigPin(GPIO_A, 5, GPIO_AF , GPIO_PUSH_PULL);
  Gpio_ConfigPin(GPIO_A, 6, GPIO_AF , GPIO_PUSH_PULL);
  Gpio_ConfigPin(GPIO_A, 7, GPIO_AF , GPIO_PUSH_PULL);

  SPI1_AF_EN();


  SPI1->CR1 |= (0x3 << SPI_CR1_SSI_Pos);  //write 1 in SSI and SSM to enable choose master slave

  SPI1->CR1 &= ~(1 << SPI_CR1_MSTR_Pos);
  SPI1->CR1 |= (MasterSlave << SPI_CR1_MSTR_Pos);

  SPI1->CR1 &= ~(1 << SPI_CR1_CPOL_Pos);
  SPI1->CR1 |= (ClkPol << SPI_CR1_CPOL_Pos);

  SPI1->CR1 &= ~(1 << SPI_CR1_CPHA_Pos);
  SPI1->CR1 |= (ClkPhase << SPI_CR1_CPHA_Pos);

  /*************************************************************************/
  // Baud Rate
  SPI1->CR1 &= ~(0x7 << SPI_CR1_BR_Pos);
  SPI1->CR1 |= (0x3 << SPI_CR1_BR_Pos);  // 16/16 -> 1MHZ
  /*************************************************************************/

  SPI1->CR1 |= (1 << SPI_CR1_SPE_Pos); //SPI enable
}

uint8 Spi1_TransmitRecieveByte(uint8 TxData) {    //TxData "transmitted data "& SPI1->DR "received data"
  if (SPI1->SR & (1 << SPI_SR_TXE_Pos)) {  // check if transmission buffer is empty
    SPI1->DR = TxData; //put the transmision data in spi data register
    while (SPI1->SR & (1 << SPI_SR_BSY_Pos)); //check for transmision complete
    return SPI1->DR; //return received data
  }
  return -1;
}
